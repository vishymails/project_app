def test_generic() :
    a = 30
    b = 40
    assert a != b

def test_mul() :
    a = 30
    b = 40
    c = a*b
    assert c >= 100