def test_generic() :
    a = 30
    b = 40
    assert a != b